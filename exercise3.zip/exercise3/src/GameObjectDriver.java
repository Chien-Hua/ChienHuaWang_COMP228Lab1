import java.util.Scanner;
import javax.swing.*;
public class GameObjectDriver {
    public static void main(String[] args) {

        GameObjectDriver Gameobject1 = new GameObjectDriver();

        Scanner input = new Scanner(System.in);

        System.out.println("Please enter the State(True=alive, False=dead) for the Gameobject1:");
        Boolean state = input.nextBoolean();
        Gameobject1.setState();
        System.out.println();

        System.out.println("Please enter the X coordinates for the center of Gameobject1:");
        double x = input.nextDouble();
        Gameobject1.setX(x);
        System.out.println();

        System.out.println("Please enter the Y coordinates for the center of Gameobject1:");
        double y = input.nextDouble();
        Gameobject1.setX(y);
        System.out.println();

        System.out.println("Please enter the Velocity for the Gameobject1:");
        double velocity = input.nextDouble();
        Gameobject1.setVelocity(velocity);
        System.out.println();

        System.out.println("Please enter the Rotation for the Gameobject1:");
        double rotation = input.nextDouble();
        Gameobject1.setRotation(rotation);
        System.out.println();

        Gameobject1.getObjectGame();

    }
}

